const express = require('express')
const routes=express.Router();
const {createStudentController,updateStudentController,getStudentByIdController,deleteStudentController,getAllStudentController}  =require('../controllers/student.controller')
routes.post("/create-student",createStudentController);
routes.get("/get-student",getAllStudentController);
routes.get("/get-student/:id",getStudentByIdController);
routes.delete("/delete-student/:id",deleteStudentController);
routes.put("/update-student/:id",updateStudentController);
module.exports=routes;