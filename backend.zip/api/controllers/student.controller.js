const Student = require("../models/student.model");

const createStudentController = async (request, response) => {
    try {
        const { name, email, gender, status, phone, college, city, dob } = request.body;
        const newStudent = await Student.create({
            name: name,
            email: email,
            gender: gender,
            status: status,
            phone: phone,
            college: college,
            dob: dob,
            city: city,
        })
        if (newStudent) {
            response.status(200).json({
                success: true,
                message: "Student Created Successfully",
                data: newStudent
            });
        }

    } catch (error) {
        response.status(500).json({ message: error.message });
    }
}

const getAllStudentController = async (request, response) => {
    try {
        const students = await Student.find();
        return response.status(200).json({ success: true, data: students, message: "Student Fetched Successfully" });
    } catch (error) {
        return response.status(500).json({ message: error.message });
    }
}


const getStudentByIdController = async (request, response) => {
    try {
        const {id}=request.params;
        const data  =await Student.findById(id);
        return response.json({status:true,message:"User Fetched Successfully for id: "+id, data: data});
        
    } catch (error) {
        return response.status(500).json({ message: error.message });
        
    }
}

const deleteStudentController =async(request, response)=>{
    try {
        const {id}=request.params;
        const data  =await Student.findByIdAndDelete(id);
        if(!data){
            return response.status(404).json({ message: 'Student not found' });
        }
        return response.json({status:true,message:"User Deleted Successfully for id: "+id, data: data});
        
    } catch (error) {
        return response.status(500).json({ message: error.message });
        
    }
}


const updateStudentController =async(request, response)=>{
    try {
        const {id}=request.params;
        const data=request.body;
        const updatedData  =await Student.findByIdAndUpdate(id, data, { new: true });
        if(updatedData){
            return response.json({status:true,message:"User Updated Successfully for id: "+id, data: updatedData});
        }
    } catch (error) {
        return response.status(500).json({status:false, message: error.message });
    }
}

module.exports = { updateStudentController,createStudentController,deleteStudentController,getStudentByIdController,getAllStudentController };