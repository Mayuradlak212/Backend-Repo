const mongoose = require('mongoose');
const { Schema } = require("mongoose");


const clgSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        undefined: true,
        default: ""
    },
    location: {
        type: String,
        unique: true,
        default: ""

    },
    city: {
        type: String,
        default: "",
        required: false,

    },
    pincode: {
        type: Number,
        required: true,
        unique: false
    },
    year: {
        type: Number,
        required: false,
        min: 2000,
        max: 2024
    },
    establishedBy: {
        type: String,
        default: "",
        required: false
    },
    createdDate: {
        type: Date,

        default: Date.now,
        required: false
    }

})

const College = mongoose.model('College', clgSchema);
module.exports =College;