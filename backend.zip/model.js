const mongoose = require('mongoose');

const { Schema } = mongoose;

const mySchema = new mongoose.Schema({

  name: {
    type: String,
    default: "",
    minlength: 3,
    maxlength: 20,
    required: true,
    unique: true,

  },
  email: {
    type: String,
    unique: true,
    default: "",
  },
  phone: {
    type: String,

  },
  status: {
    type: Boolean,
    default: false,
    required: true,
  }
});


const User = mongoose.model('User', mySchema);

module.exports = User;
