
const express = require('express');
const cors = require('cors');
const path = require("path");
const fs = require("fs");
const parser = require("body-parser");
const app = express();
const routes = express.Router();

const mongoose = require("mongoose");
const studentRoutes = require("./api/routes/student.routes")
app.use(cors({origin:"http://localhost:3000"}));
app.use(routes);
app.use(parser.json());
app.use(express.json());
app.use(studentRoutes)
app.use(cors({origin:true}));   
const port = 8000;
const uri = "mongodb+srv://swatigathiya138:IoCeHmdFyCHcYZBr@cluster0.powfvr2.mongodb.net/Backend?retryWrites=true&w=majority&appName=Cluster0";

mongoose.connect(uri).then((data) => {
    console.log("Database connected Successfully")
}).catch((err) => {
    console.log("Failed to connect with Mongoose", err.message)
})







app.listen(port, () => {
   
    console.log("Server listening on port ", port)
})