
const express = require('express');
const cors = require('cors');
const path = require("path");
const fs = require("fs");
const parser = require("body-parser");
const app = express();
const routes = express.Router();
const User = require("./model")
const mongoose = require("mongoose");
const { createUser,getUser,getCollege ,deleteUser,createCollege} = require('./controller');
app.use(routes);
app.use(parser.json());
app.use(express.json());
const port = 8000;
const uri = "mongodb+srv://swatigathiya138:IoCeHmdFyCHcYZBr@cluster0.powfvr2.mongodb.net/Backend?retryWrites=true&w=majority&appName=Cluster0";
app.use(cors());
mongoose.connect(uri).then((data) => {
    console.log("Database connected Successfully")
}).catch((err) => {
    console.log("Failed to connect with Mongoose", err.message)
})


app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname + "/index.html"))
})
//  http://localhost:8000/create-user
app.post("/create-user", createUser)

app.get("/get-users",getUser)
app.post("/create-clg",createCollege)
app.get("/get-clg",getCollege)

app.delete("/delete-user/:id",deleteUser )

app.listen(port, () => {
    //      const data={
    //         name: 'test',
    //         email: 'test@example.com',
    //         phone:"787878"
    //      }
    //    const user = new User(data);
    //    user.save().then((data)=>{
    //        console.log(data)
    //    }).catch((err)=>{
    //        console.log(err.message)
    //    })
    console.log("Server listening on port ", port)
})