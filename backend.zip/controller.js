const User = require("./model");
const College = require("./college")
const createUser = async (req, res) => {
    try {
        const user = new User(req.body);
        const savedData = await user.save();
        return res.json(savedData);
    } catch (error) {
        return res.json({ error })
    }
}
const getUser = async (req, res) => {
    try {
        const data = await User.find();
        res.json({ data })
    } catch (error) {

        res.json({ error })
    }
}
const deleteUser = async (req, res) => {
    try {
        const id = req.params.id
        const data = await User.findByIdAndDelete(id);
        res.json({ message: "User deleted successfully" });
    } catch (error) {
        res.json({ message: " Failed to Delete " });
    }
}
const updateUser = () => {
    try {

    } catch (error) {

    }
}

const createCollege =async(req,res)=>{
    try {
        const clg=new College(req.body);
        const data =await clg.save();
        return res.json(data);
    } catch (error) {
        res.json(error);
    }
}
const getCollege=async(req,res) => {
    try {
        const data = await College.find();
        res.json(data);
    } catch (error) {
        res.json(error);
    }
}

module.exports = { createUser,getCollege, getUser, deleteUser, createCollege,updateUser };